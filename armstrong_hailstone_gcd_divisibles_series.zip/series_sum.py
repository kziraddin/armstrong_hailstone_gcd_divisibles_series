def compute_series_sum(n):
    if n <= 0:
        return 0  # Return 0 for n <= 0

    series_sum = 0
    for i in range(1, n + 1):
        series_sum += i / (i + 1)

    return series_sum

# Get the input from the user
n = int(input("Enter a positive integer (n): "))

result = compute_series_sum(n)
print(f"The sum of the series for n = {n} is: {result}")
