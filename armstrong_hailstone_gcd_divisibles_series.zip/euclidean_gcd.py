def euclidean_gcd(a, b):
    while b:
        a, b = b, a % b
    return a

try:
    num1 = int(input("Enter the first number: "))
    num2 = int(input("Enter the second number: "))
    
    gcd = euclidean_gcd(num1, num2)
    
    print(f"The GCD of {num1} and {num2} is {gcd}")
except ValueError:
    print("Please enter valid integer values for the numbers.")



"""Here's a step-by-step explanation of what's happening:

while b:: This is a while loop that continues as long as the value of b is not equal to zero. In other words, 
it keeps looping until b becomes zero.

Inside the loop:

a, b = b, a % b: This line of code simultaneously updates the values of a and b. It does so using multiple assignment. 
Here's what's happening:
a is assigned the current value of b.
b is assigned the remainder when a is divided by the current value of b. This is achieved using the modulus operator (%).
For example, let's say a is 15 and b is 9. After the first iteration of the loop:

a will be updated to 9.
b will be updated to 15 % 9, which is 6.
The loop then continues, and in the next iteration, a becomes 6, and b becomes 9 % 6, which is 3. 
This process repeats until b becomes 0.

return a: When the value of b becomes zero, the loop terminates, and the GCD is found. The GCD is stored in variable a, 
and this line of code returns the GCD as the result of the euclidean_gcd function.

The Euclidean algorithm works by repeatedly taking the remainder of a divided by b and swapping the values of a and b 
until b becomes zero. At that point, a holds the GCD of the two numbers."""