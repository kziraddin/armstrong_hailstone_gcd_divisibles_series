from turtle import st


user_input = input("Enter the range: ")

user_input_str = user_input.split()

my_range = [int(num) for num in user_input_str]

#for loop use below
start_value = my_range[0] 
end_value = my_range[1]

if len(my_range)!=2:
    raise ValueError("out of Range")


for i in range(start_value, end_value+1):
    if i == 0:
        continue
    digit1 = i // 10 #gets 1st digit
    digit2 = i % 10 #gets 2nd digit

    if i % 3 == 0 and i % 5 == 0:
        print(f'{i} is divisible by 3 and 5')
        i+=5
    

   




