user_input = input("Enter the range seperated by space: ")

user_input_str = user_input.split()

user_range = [int(num)for num in user_input_str]

start_value = user_range[0]
end_value = user_range[1]

if len(user_range) != 2:
    raise ValueError("Enter valid range")

def is_armstrong_number(number):
    num_str = str(number)  # extract its digits 
    n = len(num_str)
    armstrong_sum = sum(int(digit) ** n for digit in num_str)
    return armstrong_sum == number

armstrong_numbers = []
for num in range(start_value, end_value+1):
    if is_armstrong_number(num):
        armstrong_numbers.append(num)

print(f'Armstrong numbers between {start_value} and {end_value}:', armstrong_numbers)


"""A number is said to be an Armstrong number if the sum of each of its digits when raised to the power n is equal to itself, 
where n is the total number of digits in the number. Here n is total digits in number.
For example, 371 is a three-digit Armstrong number since 33 + 73 + 13 = 371.
Write a script which finds all Armstrong numbers between 1 to 1000.
"""