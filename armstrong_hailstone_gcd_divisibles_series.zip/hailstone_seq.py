import random

user_input = input("Enter the range seperated by space: ")
user_input_str = user_input.split()
user_range = [int(num) for num in user_input_str]

start_value = user_range[0]
end_value = user_range[1]
if len(user_range)!= 2:
    raise ValueError("Enter valid range")


def generate_hailstone_iterative(n):
    sequence = [n]
    while n != 1:
        if n % 2 == 0:
            n = n // 2
        else:
            n = 3 * n + 1
        sequence.append(n)
    return sequence

random_number = random.randint(start_value, end_value) #get random number between start_value and end_value inclusive
hailstone_sequence = generate_hailstone_iterative(random_number)
num_items = len(hailstone_sequence)

print(f"No of items in hailstone series for n = {random_number} -> {num_items}")
print(f"Hailstone list for {random_number} is -> {hailstone_sequence}")

        

